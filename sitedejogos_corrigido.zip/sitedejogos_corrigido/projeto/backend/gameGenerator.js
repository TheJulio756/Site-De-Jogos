// Utilitários para geração de jogos
class GameGenerator {
  
  // Embaralhar array
  static shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  // Gerar jogo da memória
  static generateMemoryGame(terms) {
    if (terms.length < 2) {
      throw new Error('Pelo menos 2 termos são necessários para o jogo da memória');
    }

    // Criar pares de cartas (termo e definição)
    const cards = [];
    terms.forEach((term, index) => {
      cards.push({
        id: `term-${index}`,
        type: 'term',
        content: term.term,
        pairId: index
      });
      cards.push({
        id: `definition-${index}`,
        type: 'definition',
        content: term.definition,
        pairId: index
      });
    });

    // Embaralhar as cartas
    const shuffledCards = this.shuffleArray(cards);

    return {
      gameType: 'memory',
      cards: shuffledCards,
      totalPairs: terms.length,
      instructions: 'Encontre os pares correspondentes entre termos e definições'
    };
  }

  // Gerar jogo de associação
  static generateAssociationGame(terms) {
    if (terms.length < 2) {
      throw new Error('Pelo menos 2 termos são necessários para o jogo de associação');
    }

    // Separar termos e definições
    const termsList = terms.map((term, index) => ({
      id: index,
      content: term.term
    }));

    const definitionsList = terms.map((term, index) => ({
      id: index,
      content: term.definition
    }));

    // Embaralhar as definições
    const shuffledDefinitions = this.shuffleArray(definitionsList);

    return {
      gameType: 'association',
      terms: termsList,
      definitions: shuffledDefinitions,
      instructions: 'Arraste cada termo para sua definição correspondente'
    };
  }

  // Gerar jogo de quiz
  static generateQuizGame(terms) {
    if (terms.length < 4) {
      throw new Error('Pelo menos 4 termos são necessários para o jogo de quiz');
    }

    const questions = [];

    terms.forEach((term, index) => {
      // Criar alternativas incorretas (definições de outros termos)
      const wrongAnswers = terms
        .filter((_, i) => i !== index)
        .map(t => t.definition)
        .slice(0, 3); // Pegar até 3 alternativas incorretas

      // Embaralhar as alternativas
      const allAnswers = this.shuffleArray([
        term.definition, // Resposta correta
        ...wrongAnswers
      ]);

      // Encontrar o índice da resposta correta
      const correctAnswerIndex = allAnswers.findIndex(answer => answer === term.definition);

      questions.push({
        id: index,
        question: term.term,
        answers: allAnswers,
        correctAnswer: correctAnswerIndex,
        explanation: `A definição correta de "${term.term}" é: ${term.definition}`
      });
    });

    // Embaralhar as perguntas
    const shuffledQuestions = this.shuffleArray(questions);

    return {
      gameType: 'quiz',
      questions: shuffledQuestions,
      totalQuestions: questions.length,
      instructions: 'Selecione a definição correta para cada termo apresentado'
    };
  }

  // Gerar jogo baseado no tipo
  static generateGame(gameType, terms) {
    switch (gameType) {
      case 'memory':
        return this.generateMemoryGame(terms);
      case 'association':
        return this.generateAssociationGame(terms);
      case 'quiz':
        return this.generateQuizGame(terms);
      default:
        throw new Error(`Tipo de jogo não suportado: ${gameType}`);
    }
  }

  // Validar pontuação do jogo da memória
  static calculateMemoryScore(totalPairs, correctPairs, timeInSeconds) {
    const baseScore = correctPairs * 100;
    const timeBonus = Math.max(0, 300 - timeInSeconds); // Bônus por tempo (máximo 5 minutos)
    const accuracyBonus = correctPairs === totalPairs ? 200 : 0; // Bônus por completar
    
    return Math.round(baseScore + timeBonus + accuracyBonus);
  }

  // Validar pontuação do jogo de associação
  static calculateAssociationScore(totalTerms, correctAssociations, timeInSeconds) {
    const baseScore = correctAssociations * 150;
    const timeBonus = Math.max(0, 240 - timeInSeconds); // Bônus por tempo (máximo 4 minutos)
    const accuracyBonus = correctAssociations === totalTerms ? 300 : 0; // Bônus por completar
    
    return Math.round(baseScore + timeBonus + accuracyBonus);
  }

  // Validar pontuação do jogo de quiz
  static calculateQuizScore(totalQuestions, correctAnswers, timeInSeconds) {
    const baseScore = correctAnswers * 200;
    const accuracyPercentage = (correctAnswers / totalQuestions) * 100;
    const accuracyBonus = accuracyPercentage >= 80 ? 400 : accuracyPercentage >= 60 ? 200 : 0;
    const timeBonus = Math.max(0, 180 - timeInSeconds); // Bônus por tempo (máximo 3 minutos)
    
    return Math.round(baseScore + accuracyBonus + timeBonus);
  }

  // Calcular pontuação baseada no tipo de jogo
  static calculateScore(gameType, gameData) {
    switch (gameType) {
      case 'memory':
        return this.calculateMemoryScore(
          gameData.totalPairs,
          gameData.correctPairs,
          gameData.timeInSeconds
        );
      case 'association':
        return this.calculateAssociationScore(
          gameData.totalTerms,
          gameData.correctAssociations,
          gameData.timeInSeconds
        );
      case 'quiz':
        return this.calculateQuizScore(
          gameData.totalQuestions,
          gameData.correctAnswers,
          gameData.timeInSeconds
        );
      default:
        return 0;
    }
  }
}

module.exports = GameGenerator;

