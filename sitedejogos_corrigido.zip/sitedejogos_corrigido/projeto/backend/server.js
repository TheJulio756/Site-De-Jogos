const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');
const bcrypt = require('bcrypt');
const cors = require('cors');
const GameGenerator = require('./gameGenerator');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({ 
  secret: process.env.SESSION_SECRET || 'seusegredoaqui', 
  resave: false, 
  saveUninitialized: true 
}));

// Conectar ao MongoDB Atlas
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('Conectado ao MongoDB Atlas'))
.catch(err => console.error('Erro na conexão com MongoDB:', err));

// Schema do Usuário
const UserSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);

// Schema para Termos e Definições
const TermDefinitionSchema = new mongoose.Schema({
  term: { type: String, required: true },
  definition: { type: String, required: true },
  category: { type: String, default: 'geral' },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now }
});

const TermDefinition = mongoose.model('TermDefinition', TermDefinitionSchema);

// Schema para Jogos Compartilhados
const SharedGameSchema = new mongoose.Schema({
  gameType: { type: String, required: true, enum: ['memory', 'association', 'quiz'] },
  terms: [{ type: mongoose.Schema.Types.ObjectId, ref: 'TermDefinition' }],
  shareCode: { type: String, required: true, unique: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now }
});

const SharedGame = mongoose.model('SharedGame', SharedGameSchema);

// Schema para Resultados de Jogos
const GameResultSchema = new mongoose.Schema({
  gameId: { type: mongoose.Schema.Types.ObjectId, ref: 'SharedGame' },
  gameType: { type: String, required: true },
  playerName: { type: String, required: true },
  score: { type: Number, required: true },
  correctAnswers: { type: Number, required: true },
  wrongAnswers: { type: Number, required: true },
  gameTime: { type: Number, required: true }, // em segundos
  completedAt: { type: Date, default: Date.now }
});

const GameResult = mongoose.model('GameResult', GameResultSchema);

// Servir arquivos estáticos
app.use(express.static(path.join(__dirname, '../frontend/site')));
app.use('/terms-and-definitions', express.static(path.join(__dirname, '../frontend/terms-and-definitions')));

// Middleware para tratar erros de sessão
app.use((req, res, next) => {
  res.locals.error = req.session.error;
  delete req.session.error;
  next();
});

// Middleware para verificar autenticação
const requireAuth = (req, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Usuário não autenticado' });
  }
  next();
};

// === ROTAS DE AUTENTICAÇÃO ===

// Login
app.post('/login', async (req, res) => {
  try {
    const usernameOrEmail = req.body.usernameOrEmail?.trim();
    const password = req.body.password;

    if (!usernameOrEmail || !password) {
      req.session.error = 'Usuário ou senha não preenchidos';
      return res.redirect('/login.html');
    }

    const user = await User.findOne({
      $or: [{ username: usernameOrEmail }, { email: usernameOrEmail }]
    });

    if (!user) {
      req.session.error = 'Usuário não encontrado';
      return res.redirect('/login.html');
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      req.session.error = 'Senha incorreta';
      return res.redirect('/login.html');
    }

    req.session.userId = user._id;
    res.redirect('/indexcomeco.html');
  } catch (error) {
    console.error('Erro no login:', error);
    req.session.error = 'Erro interno do servidor';
    res.redirect('/login.html');
  }
});

// Registro
app.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      req.session.error = 'Todos os campos são obrigatórios';
      return res.redirect('/resgistrar.html');
    }

    const userExists = await User.findOne({ $or: [{ username }, { email }] });
    if (userExists) {
      req.session.error = 'Usuário ou email já cadastrado';
      return res.redirect('/resgistrar.html');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({
      username,
      email,
      password: hashedPassword,
    });

    await user.save();
    res.redirect('/login.html');
  } catch (error) {
    console.error('Erro no registro:', error);
    req.session.error = 'Erro ao registrar usuário';
    res.redirect('/resgistrar.html');
  }
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login.html');
  });
});

// Recuperação de senha (simulada)
app.post('/recover', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      req.session.error = 'Email é obrigatório';
      return res.redirect('/esqueciasenha.html');
    }
    
    const user = await User.findOne({ email });
    
    if (!user) {
      req.session.error = 'Email não encontrado';
      return res.redirect('/esqueciasenha.html');
    }
    
    // Simular envio de e-mail
    console.log(`Link de recuperação enviado para: ${email}`);
    req.session.success = 'Link de recuperação enviado para seu email';
    res.redirect('/esqueciasenha.html');
  } catch (error) {
    console.error('Erro na recuperação:', error);
    req.session.error = 'Erro interno do servidor';
    res.redirect('/esqueciasenha.html');
  }
});

// Alterar senha
app.post('/api/change-password', requireAuth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Senha atual e nova senha são obrigatórias' });
    }

    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    const passwordMatch = await bcrypt.compare(currentPassword, user.password);
    if (!passwordMatch) {
      return res.status(400).json({ error: 'Senha atual incorreta' });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedNewPassword;
    await user.save();

    res.json({ message: 'Senha alterada com sucesso' });
  } catch (error) {
    console.error('Erro ao alterar senha:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// === ROTAS DE TERMOS E DEFINIÇÕES ===

// Listar termos do usuário
app.get('/api/terms', requireAuth, async (req, res) => {
  try {
    const terms = await TermDefinition.find({ userId: req.session.userId })
      .sort({ createdAt: -1 });
    res.json(terms);
  } catch (error) {
    console.error('Erro ao buscar termos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Criar novo termo
app.post('/api/terms', requireAuth, async (req, res) => {
  try {
    const { term, definition, category } = req.body;
    
    if (!term || !definition) {
      return res.status(400).json({ error: 'Termo e definição são obrigatórios' });
    }

    const newTerm = new TermDefinition({
      term: term.trim(),
      definition: definition.trim(),
      category: category || 'geral',
      userId: req.session.userId
    });

    await newTerm.save();
    res.status(201).json(newTerm);
  } catch (error) {
    console.error('Erro ao criar termo:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Atualizar termo
app.put('/api/terms/:id', requireAuth, async (req, res) => {
  try {
    const { term, definition, category } = req.body;
    
    const updatedTerm = await TermDefinition.findOneAndUpdate(
      { _id: req.params.id, userId: req.session.userId },
      { term, definition, category },
      { new: true }
    );

    if (!updatedTerm) {
      return res.status(404).json({ error: 'Termo não encontrado' });
    }

    res.json(updatedTerm);
  } catch (error) {
    console.error('Erro ao atualizar termo:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Deletar termo
app.delete('/api/terms/:id', requireAuth, async (req, res) => {
  try {
    const deletedTerm = await TermDefinition.findOneAndDelete({
      _id: req.params.id,
      userId: req.session.userId
    });

    if (!deletedTerm) {
      return res.status(404).json({ error: 'Termo não encontrado' });
    }

    res.json({ message: 'Termo deletado com sucesso' });
  } catch (error) {
    console.error('Erro ao deletar termo:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// === ROTAS DE JOGOS ===

// Gerar jogo baseado nos termos do usuário
app.post('/api/games/generate', requireAuth, async (req, res) => {
  try {
    const { gameType, termIds, category } = req.body;
    
    if (!gameType) {
      return res.status(400).json({ error: 'Tipo de jogo é obrigatório' });
    }

    let terms;
    
    if (termIds && termIds.length > 0) {
      // Usar termos específicos
      terms = await TermDefinition.find({
        _id: { $in: termIds },
        userId: req.session.userId
      });
    } else if (category) {
      // Usar termos de uma categoria específica
      terms = await TermDefinition.find({
        category: category,
        userId: req.session.userId
      });
    } else {
      // Usar todos os termos do usuário
      terms = await TermDefinition.find({ userId: req.session.userId });
    }

    if (terms.length === 0) {
      return res.status(400).json({ error: 'Nenhum termo encontrado' });
    }

    // Gerar o jogo
    const gameData = GameGenerator.generateGame(gameType, terms);
    
    res.json({
      ...gameData,
      termsUsed: terms.length,
      category: category || 'todas'
    });
  } catch (error) {
    console.error('Erro ao gerar jogo:', error);
    res.status(400).json({ error: error.message });
  }
});

// Calcular pontuação de um jogo
app.post('/api/games/calculate-score', async (req, res) => {
  try {
    const { gameType, gameData } = req.body;
    
    if (!gameType || !gameData) {
      return res.status(400).json({ error: 'Tipo de jogo e dados são obrigatórios' });
    }

    const score = GameGenerator.calculateScore(gameType, gameData);
    
    res.json({ score });
  } catch (error) {
    console.error('Erro ao calcular pontuação:', error);
    res.status(400).json({ error: error.message });
  }
});

// Gerar código de compartilhamento
function generateShareCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

// Criar jogo compartilhável
app.post('/api/games/share', requireAuth, async (req, res) => {
  try {
    const { gameType, termIds } = req.body;
    
    if (!gameType || !termIds || termIds.length === 0) {
      return res.status(400).json({ error: 'Tipo de jogo e termos são obrigatórios' });
    }

    // Verificar se os termos pertencem ao usuário
    const terms = await TermDefinition.find({
      _id: { $in: termIds },
      userId: req.session.userId
    });

    if (terms.length !== termIds.length) {
      return res.status(400).json({ error: 'Alguns termos não foram encontrados' });
    }

    let shareCode;
    let codeExists = true;
    
    // Gerar código único
    while (codeExists) {
      shareCode = generateShareCode();
      const existingGame = await SharedGame.findOne({ shareCode });
      codeExists = !!existingGame;
    }

    const sharedGame = new SharedGame({
      gameType,
      terms: termIds,
      shareCode,
      createdBy: req.session.userId
    });

    await sharedGame.save();
    res.status(201).json({ shareCode, gameId: sharedGame._id });
  } catch (error) {
    console.error('Erro ao criar jogo compartilhado:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar jogo por código
app.get('/api/games/:shareCode', async (req, res) => {
  try {
    const game = await SharedGame.findOne({ shareCode: req.params.shareCode })
      .populate('terms')
      .populate('createdBy', 'username');

    if (!game) {
      return res.status(404).json({ error: 'Jogo não encontrado' });
    }

    res.json(game);
  } catch (error) {
    console.error('Erro ao buscar jogo:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// === ROTAS DE RESULTADOS ===

// Salvar resultado do jogo
app.post('/api/results', async (req, res) => {
  try {
    const { gameId, gameType, playerName, score, correctAnswers, wrongAnswers, gameTime } = req.body;
    
    if (!gameType || !playerName || score === undefined || correctAnswers === undefined || wrongAnswers === undefined || gameTime === undefined) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    const result = new GameResult({
      gameId: gameId || null,
      gameType,
      playerName: playerName.trim(),
      score,
      correctAnswers,
      wrongAnswers,
      gameTime
    });

    await result.save();
    res.status(201).json(result);
  } catch (error) {
    console.error('Erro ao salvar resultado:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Buscar resultados de um jogo
app.get('/api/results/:gameId', async (req, res) => {
  try {
    const results = await GameResult.find({ gameId: req.params.gameId })
      .sort({ score: -1, gameTime: 1 });
    
    res.json(results);
  } catch (error) {
    console.error('Erro ao buscar resultados:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// === ROTAS UTILITÁRIAS ===

// Verificar sessão
app.get('/session', (req, res) => {
  res.json({ 
    error: res.locals.error || null,
    authenticated: !!req.session.userId,
    userId: req.session.userId || null
  });
});

// Informações do usuário logado
app.get('/api/user', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.session.userId).select('-password');
    res.json(user);
  } catch (error) {
    console.error('Erro ao buscar usuário:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Rota padrão para login
app.get('/', (req, res) => {
  res.redirect('/login.html');
});

// Iniciar servidor
const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
  console.log(`Acesse: http://localhost:${PORT}/login.html`);
});

